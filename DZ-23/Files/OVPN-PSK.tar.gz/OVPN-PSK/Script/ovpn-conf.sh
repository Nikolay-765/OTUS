#!/bin/bash

DEV_Type="tun" #This can be set to "tun" or "tap"

openvpn --genkey secret /etc/openvpn/server/static.key

cat <<EOF > "/etc/openvpn/server/server.conf"
port 2194 
proto udp 
dev $DEV_Type

secret /etc/openvpn/server/static.key

ifconfig 10.8.0.1 255.255.255.0
topology subnet

keepalive 10 120 
persist-key 
persist-tun

status /var/log/openvpn-status.log 
log /var/log/openvpn.log 
verb 3
EOF

systemctl restart openvpn-server@server
systemctl enable openvpn-server@server

cat <<EOF > "/etc/openvpn/client/client.conf"
dev $DEV_Type
proto udp 
remote 192.168.50.1 2194
local 192.168.50.10

secret /etc/openvpn/client/static.key

ifconfig 10.8.0.2 255.255.255.0
topology subnet

resolv-retry infinite 

persist-key 
persist-tun 
verb 3
EOF

ssh -i /root/.ssh/Client.key -o StrictHostKeyChecking=no vagrant@192.168.50.10 'mkdir ~/OVPN-tmp'
scp -i /root/.ssh/Client.key "/etc/openvpn/client/client.conf" "/etc/openvpn/server/static.key" vagrant@192.168.50.10:'~/OVPN-tmp'
ssh -i /root/.ssh/Client.key vagrant@192.168.50.10 'sudo mv ~/OVPN-tmp/* /etc/openvpn/client && rm -rf ~/OVPN-tmp'

