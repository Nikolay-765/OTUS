#!/bin/bash

ServerName="server"
ServerDomain="ovpnserver.net"

ClientName="user"

cd /etc/openvpn/
/usr/share/easy-rsa/easyrsa --batch init-pki
/usr/share/easy-rsa/easyrsa --batch build-ca nopass

echo "$ServerDomain" | /usr/share/easy-rsa/easyrsa gen-req "$ServerName" nopass
/usr/share/easy-rsa/easyrsa --batch sign-req server "$ServerName"
/usr/share/easy-rsa/easyrsa gen-dh

cat <<EOF > "/etc/openvpn/server/$ServerName.conf"
port 2194 
proto udp 
dev tun
ca /etc/openvpn/pki/ca.crt 
cert /etc/openvpn/pki/issued/$ServerName.crt 
key /etc/openvpn/pki/private/$ServerName.key 
dh /etc/openvpn/pki/dh.pem 

server 10.8.0.0 255.255.255.0
topology subnet

ifconfig-pool-persist ipp.txt 
client-to-client 
client-config-dir /etc/openvpn/client 
keepalive 10 120 
persist-key 
persist-tun
#push "route 192.168.50.1 255.255.255.255 [IP gateway]"
push "route 0.0.0.0 0.0.0.0 10.8.0.1"
push "dhcp-option DNS 1.1.1.1" 
status /var/log/openvpn-status.log 
log /var/log/openvpn.log 
verb 3

script-security 2
up "/bin/sh -c 'iptables -t nat -A POSTROUTING -s 10.8.0.0/24 -o eth0 -j MASQUERADE'"
down "/bin/sh -c 'iptables -t nat -D POSTROUTING -s 10.8.0.0/24 -o eth0 -j MASQUERADE'"
EOF

systemctl restart openvpn-server@server
systemctl enable openvpn-server@server

/usr/share/easy-rsa/easyrsa --batch gen-req "$ClientName" nopass
/usr/share/easy-rsa/easyrsa --batch sign-req client "$ClientName"

cat <<EOF > "/etc/openvpn/client/$ClientName.conf"
dev tun 
proto udp 
remote 192.168.50.1 2194
local 192.168.50.10
client 
resolv-retry infinite 
remote-cert-tls server 
ca ./ca.crt 
cert ./$ClientName.crt 
key ./$ClientName.key 
persist-key 
persist-tun 
verb 3
EOF

ssh -i /root/.ssh/Client.key -o StrictHostKeyChecking=no vagrant@192.168.50.10 'mkdir ~/OVPN-tmp'
scp -i /root/.ssh/Client.key "./client/$ClientName.conf" vagrant@192.168.50.10:'~/OVPN-tmp'
scp -i /root/.ssh/Client.key ./pki/ca.crt "./pki/issued/$ClientName.crt" "./pki/private/$ClientName.key" vagrant@192.168.50.10:'~/OVPN-tmp'
ssh -i /root/.ssh/Client.key vagrant@192.168.50.10 'sudo mv ~/OVPN-tmp/* /etc/openvpn/client && rm -rf ~/OVPN-tmp'

